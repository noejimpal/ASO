#!/bin/bash
read -p "Introduce el primer número: " num1
read -p "Introduce el segundo número: " num2

echo "Has introducido: $num1 y $num2"
