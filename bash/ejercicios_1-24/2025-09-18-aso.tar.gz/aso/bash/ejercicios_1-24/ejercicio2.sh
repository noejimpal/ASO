#!/bin/bash
ls /etc > listado.txt
cat listado.txt
