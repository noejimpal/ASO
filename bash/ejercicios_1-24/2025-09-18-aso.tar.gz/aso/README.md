# Repositorio ASO

Este repositorio contiene los scripts y ejercicios realizados en el módulo **Administración de Sistemas Operativos (ASO)**.

## Estructura
- `bash/ejercicios_1-8/` → Scripts en Bash correspondientes a los ejercicios 1 al 8.
- `hola.sh` → Script de prueba inicial.

---

**Autor:** noejimpal  
**Correo:** noejimpal@alu.edu.gva.es

