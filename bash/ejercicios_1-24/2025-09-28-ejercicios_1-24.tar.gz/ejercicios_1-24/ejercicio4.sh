#!/bin/bash
#pedir al usuario los dos numeros
read -p "Introduce el primer número: " num1
read -p "Introduce el segundo número: " num2

#mostrar por pantalla los dos numeros
echo "Has introducido como primer numero $num1 y como segundo $num2"
