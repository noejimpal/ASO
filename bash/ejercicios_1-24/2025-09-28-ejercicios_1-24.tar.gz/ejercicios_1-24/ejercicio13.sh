#!/bin/bash

echo "1. AÑADIR"
echo "2. BUSCAR"
echo "3. LISTAR"
echo "4. ORDENAR"
echo "5. BORRAR"
echo "6. SALIR"
read -p "Introduce una opción: " opcion

case $opcion in
    1)
        echo "=== AÑADIR REGISTRO ==="
        read -p "Nombre: " nombre
        read -p "Dirección: " direccion
        read -p "Teléfono: " telefono
        echo "$nombre | $direccion | $telefono" >> lista.txt
        echo "Registro añadido correctamente."
        ;;
    2)
        echo "Opción BUSCAR seleccionada"
        ;;
    3)
        echo "Opción LISTAR seleccionada"
        ;;
    4)
        echo "Opción ORDENAR seleccionada"
        ;;
    5)
        echo "Opción BORRAR seleccionada"
        ;;
    6)
        echo "Saliendo del programa..."
        ;;
    *)
        echo "Opción no válida"
        ;;
esac

